#pragma once

extern void odomTestAuton();
extern void testAuton();

extern void twoAWPAuton();

extern void rightSideAWP2NeutralAuton();
extern void rightSideAWP1NeutralAuton();

extern void leftSideAWP1NeutralAuton();

extern void skillsAuton();
//extern void rightSideNeutralAuton();

//extern void leftSideAWPMainAuton();
//extern void leftSideNeutralAuton();

//extern void skillsAuton();