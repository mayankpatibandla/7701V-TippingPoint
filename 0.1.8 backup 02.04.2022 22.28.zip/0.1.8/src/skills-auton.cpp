#include "vex.h"
#include "auton-functions.h"

void skillsAuton(){
  fourBarMotors.setStopping(hold);
  //get yellow
  driveMotors.spin(fwd, 100, pct);
  toggleClaw();
  waitUntil(pt::x() > 43);
  toggleClaw();
  this_thread::sleep_for(20);
  leftMotors.spin(fwd, -85, pct);
  rightMotors.spin(fwd, -100, pct);
  fourBarMotors.spinFor(0.35, rev, 100, velocityUnits::pct, false);
  this_thread::sleep_for(100);
  driveMotors.spin(fwd, -100, pct);
  driveRelative(-18);
  fourBarMotors.stop(hold);
  driveMotors.stop(brake);
  driveMotors.setStopping(coast);

  //alliance mogo
  backLiftMotor.spinFor(-0.7, rev, 100, velocityUnits::pct, false);
  turnToAngle(-M_PI_2+0.03, 1500);
  timer liftTimer;
  liftTimer.reset();
  waitUntil(backLiftMotor.position(deg) < -130 || liftTimer.time(msec) > 1750);
  driveRelative(-20, 1500);
  backLiftMotor.spin(fwd, 100, pct);
  this_thread::sleep_for(200);
  driveRelative(30, 1650);
  
  //drop yellow
  turnToAngle(-M_PI_2, 500);
  ringLiftMotor.spin(fwd, 100, pct);
  fourBarMotors.spin(fwd, -100, pct);
  liftTimer.reset();
  waitUntil(fourBarBottomLimit.pressing() || liftTimer > 500);
  backLiftMotor.stop(hold);
  fourBarMotors.stop(coast);
  toggleClaw();

  //get middle yellow
  driveRelative(-25, 1500);
  turnToAngle(-0.9, 3000);
  ringLiftMotor.stop();
  driveRelative(50, 2700);
  toggleClaw();
  this_thread::sleep_for(20);
  driveMotors.spin(fwd, -100, pct);
  fourBarMotors.setStopping(hold);
  fourBarMotors.spinFor(0.35, rev, 100, velocityUnits::pct, false);

  //go forward
  turnToAngle(pt::thetaWrapped()+0.25, 700);
  driveRelative(85, 6000);
  fourBarMotors.stop(coast);
  backLiftMotor.stop(coast);
}